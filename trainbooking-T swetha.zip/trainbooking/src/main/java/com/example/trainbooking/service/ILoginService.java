package com.example.trainbooking.service;

public interface ILoginService {
}
